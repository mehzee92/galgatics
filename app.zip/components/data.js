const nftAddress = "0xe6E40219b879A1EfF367C73b93dC6Eb4a8C56439";
const rpcUrl = "https://eth-mainnet.g.alchemy.com/v2/bZ1zTwvOOOSvoDVc5QIzkIvoYD55c-vF";
const tokenAddress = "0x79BD7837e8B9Be5004FB6473b1aAFC6B21C54e8A";
const nftPrice = 0.05;

export {
    nftAddress, 
    rpcUrl,
    tokenAddress,
    nftPrice
}
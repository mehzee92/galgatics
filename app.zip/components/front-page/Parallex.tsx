import React from 'react'

function Parallex() {
  return (
    <div>Parallex</div>
  )
}

export default Parallex
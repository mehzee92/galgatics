export default function Team() {
    return(
        <div className="min-h-screen flex items-center justify-center">
             <h1 className="text-6xl sm:text-8xl mb-12 text-center">
          <span className="text-beige">COMING</span>{" "}
          <span className="text-ltBlue">SOON</span>
        </h1>
        </div>
    )
}